#!/bin/sh 

#the name of the printer will be showed in the printers list
printername="AdobePDF9.0";

#device URI of PDF Printer by Adobe Professional 9.0
deviceURI="pdf900://distiller";

#the path to the PPD file
ppd="/private/etc/cups/ppd/AdobePDF9.ppd";

lpadmin -p $printername -v $deviceURI -E -P $ppd
